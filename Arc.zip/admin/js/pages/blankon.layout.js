$(document).ready(function(){
    $.removeCookie('layout_setting');
    $.removeCookie('header_layout_setting');
    $.removeCookie('sidebar_layout_setting');
    $.removeCookie('sidebar_type_setting');
    $.removeCookie('footer_layout_setting');
});